
module.exports = {
    url: "mongodb+srv://abu:qpdBWJFHXvggQfZT@customersupportt.vcon5oe.mongodb.net/?retryWrites=true&w=majority&appName=customersupportt"
  };