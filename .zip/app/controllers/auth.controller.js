const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const User = require('../models/user.model');

// Register a new user
exports.register = (req, res) => {
  const { username, password } = req.body;

  // Validate request
  if (!username || !password) {
    return res.status(400).json({ message: 'Username and password are required.' });
  }

  // Check if the username is already taken
  User.findOne({ username })
    .then((existingUser) => {
      if (existingUser) {
        return res.status(400).json({ message: 'Username is already taken.' });
      }

      // Create a new user
      const user = new User({ username, password });

      // Hash the password
      bcrypt.genSalt(10, (err, salt) => {
        bcrypt.hash(user.password, salt, (err, hash) => {
          if (err) {
            res.status(500).json({ message: 'Failed to hash password.' });
          }

          user.password = hash;

          // Save the user in the database
          user
            .save()
            .then(() => {
              res.status(201).json({ message: 'User registered successfully.' });
            })
            .catch((error) => {
              res.status(500).json({
                message:
                  error.message || 'Some error occurred while registering the user.',
              });
            });
        });
      });
    })
    .catch((error) => {
      res.status(500).json({
        message: error.message || 'Some error occurred while registering the user.',
      });
    });
};